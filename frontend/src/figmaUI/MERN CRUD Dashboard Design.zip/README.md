
  # MERN CRUD Dashboard Design

  This is a code bundle for MERN CRUD Dashboard Design. The original project is available at https://www.figma.com/design/Upd3o5BossD4fIq4vVPV3R/MERN-CRUD-Dashboard-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  